function lab1() {
    let message;

    let form;
    let output;
    
    form = document.getElementById("theForm");
    output = document.getElementById("username").value;

    //YOOOO no way it works!
    //I'm... going to guess that getting .value like this isn't proper form though.
    const CONSTANT = document.getElementById("username").value;
    //storing text string
    if (CONSTANT !== " ") {
        message = "Welcome to AdvJava, " + CONSTANT + "!";
    }

    alert(message);
}

function init() {
    let count = 0;
    for (let i = 0; i < 5; i++) {
        count++;
        console.log(count);
    }
}